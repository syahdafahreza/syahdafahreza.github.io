<?php
$databaseHost = 'sql306.epizy.com';
$databaseName = 'epiz_33317858_np';
$databaseUsername = 'epiz_33317858';
$databasePassword = 'aRodYdr6aMF7L';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
?>