<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Booking extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Home_model');
		$this->load->model('Model_pembayaran');
		$this->load->library('form_validation');
		$this->load->library('cart');
	}
	public function index()
	{
		$data['judul'] = 'Booking Tanggal';
		$data['tanggal'] = $this->db->get('tanggal')->result_array();
		
		$this->load->view('template/header', $data);
		$this->load->view('booking_tgl');
	}

	public function jam($id)
	{
		$data['booking_tgl']=array('b_tgl'=>$id);
		$data['judul'] = 'Booking Jam';
		$data['jam'] = $this->db->get('jam')->result_array();
		
		$this->load->view('template/header', $data);
		$this->load->view('booking_jam');
	}

	public function meja($id,$id_jam)
	{
		$data['booking_tgl_jam'] = array('m_tgl'=>$id, 'm_jam'=>$id_jam);
		$data['judul'] = 'Booking Meja';
		$data['jam'] = $this->db->get('jam')->result_array();
		$data['meja']= $this->db->get('meja')->result_array();
		
		$this->load->view('template/header', $data);
		$this->load->view('booking_meja');
	}

	public function reservasi($id,$id_jam,$id_meja){
		$data = array(
			'id_user' => $this->session->userdata('id_user'),
			'id_tgl' => $id,
			'$id_jam' => $id_jam,
			'id_meja' => $id_meja,
		);
		$this->db->insert('reservasi', $data);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
	  <strong>Akun berhasil dibuat</strong>
	  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	  </button>
	</div>');
	}
}
