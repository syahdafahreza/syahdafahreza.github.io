<?php
defined('BASEPATH') or exit('No direct script access allowed');

class profile extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Home_model');
		$this->load->model('Model_pembayaran');
		$this->load->library('form_validation');
		$this->load->library('cart');
	}
	public function index()
	{
		$data['judul'] = 'Profile';
		$data['produk'] = $this->Home_model->produkbarang('');
	
        
       
		$this->load->view('admin/profile', $data);
	
	}

}