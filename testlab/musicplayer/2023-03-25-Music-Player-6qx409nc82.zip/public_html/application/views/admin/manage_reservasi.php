<div class="mr-3 ml-3" style="margin-top: 140px;">
<div class="row">
    
    <div class="col-4">
        <h5> Atur Tanggal Buka </h5>

        <div class="card">
			<div class="card-body">
                <form action="" method="post">

				<div class="form-group row">
					<div class="col">
						<label for="tgl">Buka Tanggal</label>
						<input type="date" class="form-control" id="tgl" name="tgl" required>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<button class="btn btn-primary" type="submit">Tambahkan</button>
					</div>
				</div>

                </form>
			</div>
		</div>
    </div>

    <div class="col-4">
        <h5> Atur Jam Buka </h5>

        <div class="card">
			<div class="card-body">
                <form action="" method="post">

				<div class="form-group row">
					<div class="col">
						<label for="jam_dtg">Jam Datang</label>
						<input type="time" class="form-control" id="jam_dtg" name="jam_dtg" required>
					</div>
				</div>
                <div class="form-group row">
					<div class="col">
						<label for="jam_dtg">Jam Pulang</label>
						<input type="time" class="form-control" id="jam_plg" name="jam_plg" required>
					</div>
				</div>

				<div class="row">
					<div class="col">
						<button class="btn btn-primary" type="submit">Tambahkan</button>
					</div>
				</div>

                </form>
			</div>
		</div>
    </div>

    <div class="col-4">
        <h5> Atur Meja </h5>

        <div class="card">
			<div class="card-body">
                <form action="" method="post">

				<div class="form-group row">
					<div class="col">
						<label for="tgl">No Meja</label>
						<input type="text" class="form-control" id="meja" name="meja" required>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<button class="btn btn-primary" type="submit">Tambahkan</button>
					</div>
				</div>

                </form>
			</div>
		</div>
    </div>
    
</div>
</div>