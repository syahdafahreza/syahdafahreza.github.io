<form>
	<div class="container-fluid">
		<div style="margin-top:130px;">
			<div class="container-fluid">
				<table class="table table-sm table-bordered table-striped table-hover">
					<tr align="center">
						<th>No</th>
						<th>Jam</th>
						<th></th>
					</tr>
					<?php
					$no = 1;
					foreach ($jam as $j) : ?>
						<tr>
							<td align="center"><?= $no++ ?></td>
							<td><?= $j['jam_dtg']. ' s.d. '. $j['jam_plg'] ?></td>
							<td><a href="<?php echo base_url('Booking/meja/'.$booking_tgl['b_tgl'].'/'.$j['id_jam'])?>" class="badge-success badge-pill text-white">Pilih</a> </td>
			</div>
		</div>
		
		</tr>
	<?php endforeach; ?>
	
	</table>
</form>
<footer>
	
</footer>
