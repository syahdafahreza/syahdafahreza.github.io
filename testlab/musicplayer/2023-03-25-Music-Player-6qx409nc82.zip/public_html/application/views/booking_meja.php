<div class="container-fluid">
		<div style="margin-top:130px;">
        <h3><?php echo $judul?></h3>




			<div class="container-fluid d-flex justify-content-center ">
                <div class="col-8">
                    <div class="row d-flex justify-content-center">
                        <?php foreach ($meja as $m) : ?>
                            <a href=<?php echo base_url('booking/reservasi/').$booking_tgl_jam['m_tgl'].'/'.$booking_tgl_jam['m_jam'].'/'.$m['id_meja']?> style="color:black;text-decoration: none">
                                <div class="col-5 bg-info p-5 m-2">
                                    <h3><?php echo $m['meja']?></h3>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
			</div>





		</div>
</div>