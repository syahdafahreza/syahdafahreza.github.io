<form>
	<div class="container-fluid">
		<div style="margin-top:130px;">
			<div class="container-fluid">
				<table class="table table-sm table-bordered table-striped table-hover">
					<tr align="center">
						<th>No</th>
						<th>Tanggal</th>
						<th></th>
					</tr>
					<?php
					$no = 1;
					foreach ($tanggal as $tgl) : ?>
						<tr>
							<td align="center"><?= $no++ ?></td>
							<td><?= date('d F Y',strtotime($tgl['tgl'])) ?></td>
							<td><a href="<?php echo base_url('Booking/jam/'.$tgl['id_tgl'])?>" class="badge-success badge-pill text-white">Pilih</a> </td>
			</div>
		</div>
		
		</tr>
	<?php endforeach; ?>
	
	</table>
</form>
<footer>
	
</footer>
