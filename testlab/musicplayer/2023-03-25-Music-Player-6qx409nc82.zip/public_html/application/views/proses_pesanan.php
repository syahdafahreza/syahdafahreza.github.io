<div style="margin-top:100px;">
	<div class="alert alert-success" role="alert">
		<div class="container-fluid" align="center">
			<h4 class="alert-heading">Alhamdulillah!</h4>
			<p>Pesanan Anda sudah kami terima, Terima Kasih.</p>
			<hr>
			<p class="mb-0">Akan kami proses. *(<a href="<?= base_url('home/cetak/') . $query->id_order ?>" target="_blank">Cetak Invoice</a>)</p>
			<button class="btn badge-pill badge-succes fas fa-shopping-cart"><a href="<?= base_url('Home/#produk') ?>">
					Lanjutkan Belanja</a>
			</button>
		</div>
	</div>
</div>
