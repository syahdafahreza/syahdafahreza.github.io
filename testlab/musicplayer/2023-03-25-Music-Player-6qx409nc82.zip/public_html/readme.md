# Aplikasi Sistem Reservasi Restoran

## Cara Install
1. Silahkan clone atau download repository ini.
2. Import database yang berada di `.\_db\sistem_reservasi_restoran.sql` ke MySQL Database anda.
3. Lakukan konfigurasi pada `.\application\config\database.php` untuk mengatur database (atur username, password dan database).
4. (opsional)Check apakah file .htaccess sudah ada atau tidak. Jika tidak ada,Tambahkan file .htaccess untuk bypass index.php .
5. Done, silahkan jalankan website.
