<?php
$databaseHost = 'sql306.epizy.com';
$databaseUsername = 'epiz_33317858';
$databasePassword = 'aRodYdr6aMF7L';
$databaseName = 'epiz_33317858_tog';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
?>